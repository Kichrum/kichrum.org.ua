﻿<?
 /* 
	tvkontakte 0.1i
	vkontakte.ru status updater from twitter
	made by Vladimir Smirnoff
	http://orl.sumy.ua
	mail@smirnoff.sumy.ua
	improved by Kichrum
	http://Kichrum.org.ua
 */

# Конфигурация - ОТРЕДАКТИРУЙ!
define ('TWITTER_USERNAME','MyLogin'); // MyLogin заменить на свой Логин в Twitter
define ('VKONTAKTE_LOGIN','user@mail.ua'); // user@mail.ua заменить на свой E-mail на Vkontakte.ru
define ('VKONTAKTE_PASSWORD','gfhjkm'); // gfhjkm  заменить на свой Пароль на Vkontakte.ru
define ('PREPEND_WORD','Twitter.com/Kichrum '); // Twitter.com/Kichrum  заменить на Слово,  которое будет перед статусом: максимальная длинна: 20 символов с пробелами = 160 во vkontakte - 140 в twitter 
# Конфигурация выполнена.

# Дальше можно не читать :)

# Объявляем Дуровский UserAPI
class vkuserapi {
	private $curlh = null;
	public $uid = null;
	private $sid = null;
	
	public function __construct ($login,$password) {
		$this->curlh = curl_init();
		$request = 'http://login.userapi.com/auth?site=2&login=force&pass='.urlencode($password).'&email='.urlencode($login);
		curl_setopt($this->curlh, CURLOPT_URL,$request);
		curl_setopt($this->curlh, CURLOPT_FAILONERROR, true);
		curl_setopt($this->curlh, CURLOPT_FOLLOWLOCATION, false);
		curl_setopt($this->curlh, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($this->curlh, CURLOPT_POST, false); 
		curl_setopt($this->curlh, CURLOPT_HEADER, true);
		$auth_result = curl_exec($this->curlh);
		if (preg_match("/remixmid=(\d+)/", $auth_result, $matches)) $this->uid = $matches[1];
		if (preg_match("/.*;sid=(\w*)/", $auth_result, $matches)) $this->sid = $matches[1];
	}
	
	public function call ($func,$params) {
		curl_setopt($this->curlh, CURLOPT_HEADER, false);
		$request = 'http://userapi.com/data?act='.$func.'&'.http_build_query ($params).'&sid='.$this->sid;
		curl_setopt($this->curlh, CURLOPT_URL,$request);
		$result = curl_exec($this->curlh);
		return json_decode($result);
	}
	
	public function __destruct () {
		$request = 'http://login.userapi.com/auth?login=logout&site=2&sid='.$this->sid;
		curl_setopt($this->curlh, CURLOPT_URL,$request);
		curl_exec($this->curlh);
		curl_close ($this->curlh);
	}
}

# Берем статус со своей RSS-ленты на Twitter.com
$rss = simplexml_load_file('http://twitter.com/statuses/user_timeline/'.TWITTER_USERNAME.'.rss');
# Убираем лишнюю информацию
foreach ($rss->channel->item as $status) {
	if (strpos($status->title,'@')) continue; // Фильтр реплаев в Twitter
	$last_status_twitter = str_replace (TWITTER_USERNAME.': ','',$status->title); break;
}

# Читаем последний обновлённый статус из файла vtweet.txt
$f=fopen(dirname(__FILE__).'/vtweet.txt','r');
$last_status_vkontakte = fread($f,512);
fclose($f);

# Если последний статус ещё не опубликован во В Контакте, публикуем и помечаем его как обновлённый
if (($last_status_vkontakte != $last_status_twitter) && ($last_status_twitter != NULL)) {
$vkontakte = new vkuserapi (VKONTAKTE_LOGIN,VKONTAKTE_PASSWORD); // Логинимся
$vkontakte->call ('set_activity',array('ts'=>time(),'text'=>PREPEND_WORD.$last_status_twitter)); // Обновляем статус
unset ($vkontakte); // Выходим из Vkontakte.ru
$f=fopen(dirname(__FILE__).'/vtweet.txt','w');
fwrite($f,$last_status_twitter); // "Помечаем" статус как уже обновлённый
fclose($f);
echo 'Updatetd.';
}
else echo 'No update needed.'; // Если последний уже помечен, выводим внутреннюю ошибку.

# Завершаем работу программы.
?>