﻿<?
header('location: http://kichrum.org.ua/');
?>