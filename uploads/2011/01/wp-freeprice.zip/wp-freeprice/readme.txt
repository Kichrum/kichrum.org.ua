=== WP FreePrice ===
Contributors: Kichrum
Donate link: http://kichrum.org.ua/about/contact
Tags: shop, price, free, webmoney, sms, a1pay, attachment, download
Requires at least: 2.8
Tested up to: 2.8
Stable tag: 1.0

Convert standard attachment to the free-price store.

== Description ==

This plugin transforms a standard system of downloading attached files to the store of free prices.

You can also read a detailed <a href="http://kichrum.org.ua/projects/wp-freeprice">russian description</a> of this plugin.

== Installation ==

1. Upload directory 'wp-freeprice/' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Configure plugin through WP FreePrice menu in Options
4. Register at the A1Pay: https://home.a1pay.ru/main/register/
5. The remaining instructions in the screenshots: http://kichrum.org.ua/projects/wp-freeprice

== Changelog ==

= 1.0 =

* First stable version