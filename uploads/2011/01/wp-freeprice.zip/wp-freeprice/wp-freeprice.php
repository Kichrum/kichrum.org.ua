<?php 
/*
Plugin Name: WP FreePrice
Plugin URI: http://kichrum.org.ua/projects/wp-freeprice
Description: Free Price Shop on WordPress
Version: 1.0
Author: Sergey Pashko aka Kichrum
Author URI: http://kichrum.org.ua
*/

function wpfp_A1Lite_processor ($t,$secret)
{
    $params = array('tid' => $t['tid'],
        'name' => $t['name'], 
        'comment' => $t['comment'],
        'partner_id' => $t['partner_id'],
        'service_id' => $t['service_id'],
        'order_id' => $t['order_id'],
        'type' => $t['type'],
        'partner_income' => $t['partner_income'],
        'system_income' => $t['system_income']
    );
    $params['check'] = md5(join('', array_values($params)) . $secret);
    if ($params['check'] === $t['check'])
        $ok = true;
    else
        $ok = false;
    return $ok;
}

function wpfp_form($content)
{
    $options = get_option('wp_free_price');
    $att_file_url = wp_get_attachment_url();
    $att_name = get_the_title();
    $price = rand(10, 500);
    global $post;
    $pid = $post->ID;
    $answer = "<p>{$post->post_content}</p>";
    $att_strong_link = "<strong><a href='$att_file_url'>Скачать $att_name</a></strong>";
    $form = "<form method='post' accept-charset='UTF-8' action='https://partner.a1pay.ru/a1lite/input'>
                <input type='hidden' name='key' value='{$options['wpfp_public_key']}' />
                <label for='cost'>{$options['wpfp_price_form']}</label>
                <input id='cost' type='text' title='Минимум: 1 рубль' name='cost' value='$price' style='width:45px;padding:2px;text-align:left;border-top:0;border-left:0;border-right:0; border-bottom: 1px solid black;font-style:italic;' />
                <label for='cost'>руб.</label>
                <input type='hidden' name='name' value='Купить $att_name по свободной цене' />
                <input type='hidden' name='default_email' value='' />
                <input type='hidden' name='comment' value='$pid' />
                <input type='hidden' name='order_id' value='0' />
                <input type='submit' value='Оплатить' style='font-size: x-large;' />
            </form>";
    $download = "<p class='attachment'>$att_strong_link (если, конечно, загрузка не началась автоматически)</p>";
    //$download .= "<meta http-equiv='refresh' content='5;url=$att_file_url' />";
    $download .= "<script type='text/javascript'>function redirect(){window.location = '$att_file_url';}setTimeout(redirect, 5000);</script>";
    if(isset($_SERVER['QUERY_STRING']) && strpos(' ' . $_SERVER['QUERY_STRING'],'free') && $options['wpfp_allow_free'])
        $answer .= "<p>{$options['wpfp_free_message']}</p>\n$download\n$form";
    elseif(isset($_GET['result']))
    {
        if($_GET['result'] === 'error')
            $answer .= "<p>{$options['wpfp_error_message']}</p>\n$download\n$form";
        else
            $answer .= "<p>{$options['wpfp_thank_message']}</p>\n$download";
    }
    else
    {
        $answer .= "<p>{$options['wpfp_buy_message']}</p>";
        $answer .= $form;
        if($options['wpfp_allow_free'])
            $answer .= "<form method='post' action='?p=$pid&free' style='text-align: right;'>
                    <input type='submit' value='{$options['wpfp_download_button']}' style='font-size: x-small;' />
                </form>";
    }
    if($options['wpfp_allow_author'])
        $answer .= "<p>Автор <a href='http://kichrum.org.ua/projects/wp-freeprice/' title='Плагин магазина свободных цен'>магазина свободных цен</a> для WordPress: <a href='http://kichrum.org.ua' title='Kichrum's Blog'>Kichrum</a>.</p>";
    echo $answer;
}
function free_price()
{
    if(!is_attachment() || wp_attachment_is_image())
        return;
    add_filter('the_content', 'wpfp_form');
}
function wpfp_check_headers()
{
    $request = $_SERVER['REQUEST_METHOD'] == 'GET' ? $_GET : $_POST;
    if(isset($request['tid']))
    {
        $options = get_option('wp_free_price');
        if(wpfp_A1Lite_processor($request, $options['wpfp_secret_key']))
        {
            $data = get_option('wp_free_price_data');
            $data['downloads'][] = $request;
            update_option('wp_free_price_data', $data);
            header("location: ?p={$request['comment']}&result={$request['check']}");
        }
        else
            header("location: ?p={$request['comment']}&result=error");
        exit();
    }
}
function wpfp_options()
{
    if (isset($_POST['wpfp_thank_message']))
        update_option('wp_free_price', $_POST);
    $options = get_option('wp_free_price');
    
    ?>
<div class="wrap">
  <h2>WP FreePrice</h2>
  <form method="post">
    <table class="form-table">
      <tr>
        <td>Секретный ключ:</td>
        <td><input type="text" name="wpfp_secret_key" style="width:400px" value="<?php echo $options['wpfp_secret_key']; ?>" /></td>
      </tr>
      <tr>
        <td>Открытый ключ:</td>
        <td><input type="text" name="wpfp_public_key" style="width:400px" value="<?php echo $options['wpfp_public_key']; ?>" /></td>
      </tr>
      <tr>
        <td>Разрешить бесплатное скачивание?</td>
        <td><input type="checkbox" name="wpfp_allow_free" value="checked" <?php echo $options['wpfp_allow_free']; ?> /></td>
      </tr>
      <tr>
        <td>Выводить ссылку на автора скрипта?</td>
        <td><input type="checkbox" name="wpfp_allow_author" value="checked" <?php echo $options['wpfp_allow_author']; ?> /></td>
      </tr>
      <tr>
        <td>Описание на странице покупки:</td>
        <td><textarea name="wpfp_buy_message" style="width:400px"><?php echo $options['wpfp_buy_message']; ?></textarea></td>
      </tr>
      <tr>
        <td>Описание поля ввода цены:</td>
        <td><input type="text" name="wpfp_price_form" style="width:400px" value="<?php echo $options['wpfp_price_form']; ?>" /></td>
      </tr>
      <tr>
        <td>Если произошла ошибка:</td>
        <td><textarea name="wpfp_error_message"style="width:400px"><?php echo $options['wpfp_error_message']; ?></textarea></td>
      </tr>
      <tr>
        <td>Перед бесплатным скачиванием:</td>
        <td><textarea name="wpfp_free_message" style="width:400px"><?php echo $options['wpfp_free_message']; ?></textarea></td>
      </tr>
      <tr>
        <td>Благодарность за оплату:</td>
        <td><textarea name="wpfp_thank_message" style="width:400px"><?php echo $options['wpfp_thank_message']; ?></textarea></td>
      </tr>
      <tr>
        <td>Надпись на кнопке для бесплатного скачивания:</td>
        <td><input type="text" name="wpfp_download_button" style="width:400px" value="<?php echo $options['wpfp_download_button']; ?>" /></td>
      </tr>
    </table>
    <input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />

  </form>
</div>

    <?php
}

function wpfp_admin()
{
    add_options_page('WP FreePrice', 'WP FreePrice', 'manage_options', 'wp_free_price', 'wpfp_options');
}

$wpfp_options = array(
				'wpfp_secret_key' => '',
				'wpfp_public_key' => '',
                'wpfp_allow_free' => 'checked',
                'wpfp_allow_author' => 'checked',
                'wpfp_buy_message' => 'Этот файл можно купить по свободной цене с помощью WebMoney, Яндекс.Денег, QIWI, SMS и множеством других способов.',
                'wpfp_price_form' => 'Я заплачу за этот файл',
				'wpfp_error_message' => 'Произошла какая-то ошибка :( Но не отчаивайся! Ты в любом случае можешь скачать этот файл:',
                'wpfp_free_message' => 'Не важно, заплатил ты или нет. Ты в любом случае можешь скачать этот файл:',
				'wpfp_thank_message' => 'Спасибо, что сделал пожертвование! Родина тебя не забудет :) Теперь можешь скачать этот файл:',
                'wpfp_download_button' => 'Лазейка для жадин'
			);
$wpfp_data = array();

add_option('wp_free_price', $wpfp_options,'WP FreePrice Options');
add_option('wp_free_price_data', $wpfp_data,'WP FreePrice Data');
add_action('init', 'wpfp_check_headers');
add_action('the_post', 'free_price');
add_action('admin_menu', 'wpfp_admin');

?>