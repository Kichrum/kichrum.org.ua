<?php 
/*
Plugin Name: WP Whisper
Plugin URI: http://kichrum.org.ua/projects/wp-whisper
Description: Posting marked comments only the blog author, without displaying for other visitors.
Version: 1.0
Author: Sergey Pashko aka Kichrum
Author URI: http://kichrum.org.ua
*/

/**
 * Флажок под кнопкой отправки комментария.
 */
function wp_whisper_flag()
{
    echo "\n"
        . '<p class="only_author_flag">' // Стиль для абзаца с флажком - p.only_author_flag - можно настроить через style.css
        . '<input id="only_author_flag" type="checkbox" name="only_author_flag" value="true" />' // id флажка также #only_author_flag
        . '<label for="only_author_flag" title="'
        // Текст, отображаемый при наведении курсора на описание к флажку:
        . 'Например, если в комментарии содержится указание на ошибку в тексте или просьба исправить предыдущий комментарий... Обратная связь в общем'
        . '">'
        // Текст описания флажка:
        . 'Обращение к автору блога (не публиковать для всех)'
        . '</label>'
        . '</p>';
}

/**
 * Перехват и отправка на модерацию.
 */
function wp_whisper_approved($approved)
{
    if($_POST['only_author_flag'] == 'true')
        return 0; // Строгая отправка комментария на модерацию
    else
        return $approved; // Сохранение комментария по правилам антиспамов и прочих встроенных систем
}

/**
 * Дописываем, что этот комментарий отправлен на модерацию вручную, а не встроенными системами.
 */
function wp_whisper_process($commentdata)
{
    if($_POST['only_author_flag'] == 'true')
        $commentdata['comment_content'] = 
            // Комментарии автору будут помечаться этим текстом:
            "<blockquote>[Комментарий доступен только автору блога]</blockquote>\n" // (Выглядит как цитата)
            . $commentdata['comment_content'];
    return $commentdata;
}

add_action('comment_form', 'wp_whisper_flag');
add_filter('preprocess_comment', 'wp_whisper_process');
add_filter('pre_comment_approved', 'wp_whisper_approved');

?>