=== WP Whisper ===
Contributors: Kichrum
Donate link: http://kichrum.org.ua/about/contact
Tags: whisper, comments, form, simple, moderation, flags
Requires at least: 2.8
Tested up to: 2.8
Stable tag: 1.0

Comments "to admin only" flag.

== Description ==

This plugin adds flag "for admin only" to comment form. Posting marked comments only the blog author, without displaying for other visitors.

You can also read a detailed <a href="http://kichrum.org.ua/projects/wp-whisper">russian description</a> of this plugin.

== Installation ==

1. Upload directory 'wp-whisper/' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Enjoy!

== Changelog ==

= 1.0 =

* First stable version